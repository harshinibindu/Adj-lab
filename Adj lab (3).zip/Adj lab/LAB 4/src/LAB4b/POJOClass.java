package exp4;

public class POJOClass {

//Declare variables which are matched with CSV columns.

    String Regno;
    String SGPA;
   
    // Add getters and setters methods
   
public String getRegno() {
return Regno;
}
public void setRegno(String regno) {
Regno = regno;
}
public String getSGPA() {
return SGPA;
}
public void setSGPA(String sGPA) {
SGPA = sGPA;
}

}